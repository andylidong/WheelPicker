package com.aigestudio.wheelpicker.view;

interface IWheelCrossPicker {
    void setOrientation(int orientation);
}