package com.aigestudio.wheelpicker.widget;

/**
 * @author AigeStudio 2015-12-20
 */
public interface IDigital {
    void setDigitType(int type);
}